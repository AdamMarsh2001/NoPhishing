function highlightText() {
    var divs = document.getElementsByClassName("gs");

    var wordList = JSON.stringify(spellingMistakes).replaceAll("\"","").replaceAll("[","").replaceAll("]","")
    var wordArray = wordList.split(",");

    for (let j = 0; j < wordArray.length; j++) {
        word = wordArray[j];
        var regEx = new RegExp(word, "ig")
        for (var i = 0; i < divs.length; i++) {
            divs[i].innerHTML = divs[i].innerHTML.replaceAll(regEx, " <span style='color:GoldenRod;'>" + word + "</span>")
        }
    }   
}

highlightText()