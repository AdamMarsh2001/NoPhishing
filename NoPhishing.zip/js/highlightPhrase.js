function highlightText() {
    var divs = document.getElementsByClassName("gs");

    var phraseList = JSON.stringify(phrases).replaceAll("\"","").replaceAll("[","").replaceAll("]","")
    var phraseArray = phraseList.split(",");

    for (let j = 0; j < phraseArray.length; j++) {
        phrase = phraseArray[j];
        var regEx = new RegExp(phrase, "ig")
        for (var i = 0; i < divs.length; i++) {
            divs[i].innerHTML = divs[i].innerHTML.replaceAll(regEx, " <span style='color:red;'>" + phrase + "</span>")
        }
    }    
}

highlightText()
