function getMessageID() {
    try{
        return document.querySelector('[data-message-id]').getAttribute('data-legacy-message-id');
    }catch(error){
        return "error"
    }
}

chrome.runtime.sendMessage({
    action: "getMessageID",
    source: getMessageID()
});